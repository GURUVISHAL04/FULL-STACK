class Employee{
    String name;
    int id;
    Employee(String name,int id){
        this.name = name;
        this.id = id;
}
public void displayinfo(){
    System.out.println("Employee name :" + name);
    System.out.println("Employee id:" + id);
}
}
class Manager extends Employee{
    String department;
    Manager(String name,int id,String department){
        super(name,id);
        this.department = department;
    }
    public void displaymanagerinfo(){
        displayinfo();
        System.out.println("Department :" + department);
    }
}
public class Company{
    public static void main(String[] args){
        Manager m1 = new Manager("Karthik",1234,"Techinical");
        m1.displaymanagerinfo();
    }
}
// 1. Single Inheritance (with Constructor)
// A company maintains employee records. Every Employee has a name and ID. A Manager is a special type of employee who also has a department name. Design:
//  Class Employee: contains name, empId and a constructor to initialize them.  Class Manager: inherits from Employee and adds department, with its own
// constructor that calls the superclass constructor. Create an object of Manager, initialize all values using constructors, and display the
// complete information using a method. 2. Multilevel Inheritance (with Constructor)