class BillCalculator {
    double calculateBill(double price, int quantity) {
        return price * quantity;
    }
    double calculateBill(double price, int quantity, double discount) {
        double total = price * quantity;
        double discountAmount = (discount / 100) * total;
        return total - discountAmount;
    }
    double calculateBill(double[] prices) {
        double total = 0;
        for (double price : prices) {
            total += price;
        }
        return total;
    }
}
public class OnlineStoreBilling {
    public static void main(String[] args) {
        BillCalculator bill = new BillCalculator();
        double total1 = bill.calculateBill(500.0, 2);
        System.out.println("Total (Single Product): ₹" + total1);
        double total2 = bill.calculateBill(800.0, 3, 10.0);
        System.out.println("Total (With Discount): ₹" + total2);
        double[] multiplePrices = { 250.0, 450.0, 300.0, 500.0 };
        double total3 = bill.calculateBill(multiplePrices);
        System.out.println("Total (Multiple Orders): ₹" + total3);
    }
}


// A billing system for an online store calculates the total bill based on different
// scenarios:
//  If a customer buys a single product, the system calculates the price using the
// product price and quantity.  If the customer has a discount coupon, the system applies the discount to the total.  For bulk orders (more than one product), the system takes an array of product
// prices and calculates the total. Design:
//  Create a class BillCalculator with overloaded methods named calculateBill as
// follows:
//  calculateBill(double price, int quantity) — calculates total price.  calculateBill(double price, int quantity, double discount) — applies a percentage
// discount.  calculateBill(double[] prices) — sums up all prices in the array. Task:
// Create a Java program that:
//  Defines the overloaded methods in BillCalculator.