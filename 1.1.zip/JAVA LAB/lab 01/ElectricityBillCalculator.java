import java.util.Scanner;

public class ElectricityBillCalculator {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter number of units consumed: ");
        int units = scanner.nextInt();

        double bill = 0;
        if (units <= 100) {
            bill = units * 2;
        } else if (units <= 300) {
            bill = (100 * 2) + ((units - 100) * 3);
        } else {
            bill = (100 * 2) + (200 * 3) + ((units - 300) * 5);
        }
        if (bill > 1000) {
            double surcharge = bill * 0.10; // 10% surcharge
            bill += surcharge;
            System.out.printf("Surcharge of ₹%.2f added.\n", surcharge);
        }
        System.out.printf("Total Electricity Bill: ₹%.2f\n", bill);

        scanner.close();
    }
}
