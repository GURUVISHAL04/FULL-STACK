class BankAccount {
    private String accountNumber;
    private String accountHolderName;
    private double balance;

    public String getAccountNumber()
    { return accountNumber; }
    public void setAccountNumber(String accountNumber) 
    { this.accountNumber = accountNumber; }

    public String getAccountHolderName()
    { return accountHolderName; }
    public void setAccountHolderName(String accountHolderName) 
    { this.accountHolderName = accountHolderName; }

    public double getBalance() 
    { return balance; }
    public void setBalance(double balance) {
        if (balance < 0) {
            System.out.println("Warning: Balance cannot be negative.");
        } else {
            this.balance = balance;
        }
    }

    public void deposit(double amount) {
        if (amount > 0) {
            balance += amount;
            System.out.println("Deposited: ₹" + amount);
        } else {
            System.out.println("Invalid deposit amount.");
        }
    }

    public void withdraw(double amount) {
        if (amount <= balance) {
            balance -= amount;
            System.out.println("Withdrawn: ₹" + amount);
        } else {
            System.out.println("Insufficient funds.");
        }
    }
}

public class BankAccountMain {
    public static void main(String[] args) {
        BankAccount account = new BankAccount();
        account.setAccountNumber("ACC123456");
        account.setAccountHolderName("Hari");
        account.setBalance(5000.0);

        account.deposit(2000);
        account.withdraw(1000);
        account.withdraw(7000);

        System.out.println("Final Balance: ₹" + account.getBalance());
    }
}
