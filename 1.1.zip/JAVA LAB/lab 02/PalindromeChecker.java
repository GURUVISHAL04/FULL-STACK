public class PalindromeChecker {
    public static boolean isPalindrome(String input) {
        String cleaned = input.toLowerCase().replaceAll("[^a-z0-9]", "");
        String reversed = new StringBuilder(cleaned).reverse().toString();
        return cleaned.equals(reversed);
    }

    public static void main(String[] args) {
        String text = "A man, a plan, a canal: Panama";
        boolean result = isPalindrome(text);
        System.out.println("Is palindrome? " + result);
    }
}
