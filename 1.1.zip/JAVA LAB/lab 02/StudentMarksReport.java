import java.util.Scanner;

public class StudentMarksReport {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        int students = 5;
        int subjects = 3;

        String[] names = new String[students];
        int[][] marks = new int[students][subjects];

        for (int i = 0; i < students; i++) {
            System.out.print("Enter name of student " + (i + 1) + ": ");
            names[i] = scanner.nextLine();

            System.out.println("Enter marks for 3 subjects:");
            for (int j = 0; j < subjects; j++) {
                System.out.print("Subject " + (j + 1) + ": ");
                marks[i][j] = scanner.nextInt();
            }
            scanner.nextLine(); 
        }

        System.out.println("\n--- Student Averages ---");

        for (int i = 0; i < students; i++) {
            int total = 0;
            for (int j = 0; j < subjects; j++) {
                total += marks[i][j];
            }
            double avg = total / (double) subjects;
            System.out.printf("%s - Average: %.2f%%\n", names[i], avg);
        }

        System.out.println("\nStudents scoring more than 75%:");
        for (int i = 0; i < students; i++) {
            int total = 0;
            for (int j = 0; j < subjects; j++) {
                total += marks[i][j];
            }
            double avg = total / (double) subjects;
            if (avg > 75) {
                System.out.println(names[i]);
            }
        }

        scanner.close();
    }
}
