import java.util.Scanner;

public class NameProcessor {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your full name: ");
        String fullName = scanner.nextLine().trim();
        String[] parts = fullName.split(" ");
        String firstName = parts[0];
        String lastName = parts.length > 1 ? parts[parts.length - 1] : "";
        String initials = firstName.charAt(0) + "." + (lastName.isEmpty() ? "" : lastName.charAt(0) + ".");
        System.out.println("First Name: " + firstName);
        System.out.println("Last Name: " + lastName);
        System.out.println("Initials: " + initials);
        System.out.println("Uppercase: " + fullName.toUpperCase());
        System.out.println("Lowercase: " + fullName.toLowerCase());
        if (fullName.toLowerCase().contains("z")) {
            System.out.println("The name contains the letter 'z'.");
        } else {
            System.out.println("The name does not contain the letter 'z'.");
        }
        System.out.println("With underscores: " + fullName.replace(" ", "_"));
        System.out.println("Words in the name:");
        for (String word : parts) {
            System.out.println(word);
        }
        int length = fullName.length();
        System.out.println("Length of the name: " + length);
        if (length >= 4) {
            System.out.println("Character at position 3: " + fullName.charAt(3));
        } else {
            System.out.println("The name is too short to have a character at position 3.");
        }
        System.out.println("Hello, " + fullName + "! Your name has " + length + " characters.");

        scanner.close();
    }
}
