import java.util.Scanner;

public class PasswordValidator {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your password: ");
        String password = scanner.nextLine();
        boolean hasUppercase = false;
        boolean hasDigit = false;
        boolean hasNoSpace = !password.contains(" ");
        boolean longEnough = password.length() >= 8;
        for (int i = 0; i < password.length(); i++) {
            char ch = password.charAt(i);

            if (Character.isUpperCase(ch)) {
                hasUppercase = true;
            }
            if (Character.isDigit(ch)) {
                hasDigit = true;
            }
        }
        if (longEnough && hasUppercase && hasDigit && hasNoSpace) {
            System.out.println(" Password is valid.");
        } else {
            System.out.println(" Password is invalid. Reasons:");
            if (!longEnough) System.out.println("- Must be at least 8 characters long");
            if (!hasUppercase) System.out.println("- Must contain at least one uppercase letter");
            if (!hasDigit) System.out.println("- Must contain at least one number");
            if (!hasNoSpace) System.out.println("- Must not contain spaces");
        }

        scanner.close();
    }
}
