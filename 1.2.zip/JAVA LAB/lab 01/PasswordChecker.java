import java.util.Scanner;

public class PasswordChecker {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        final String correctPassword = "java123";
        int attempts = 0;
        final int maxAttempts = 3;

        while (attempts < maxAttempts) {
            System.out.print("Enter password: ");
            String input = scanner.nextLine();

            if (input.equals(correctPassword)) {
                System.out.println("Access Granted");
                break;
            } else {
                attempts++;
                System.out.println("Incorrect password. Attempts left: " + (maxAttempts - attempts));
            }
        }

        if (attempts == maxAttempts) {
            System.out.println("Access Denied");
        }

        scanner.close();
    }
}
