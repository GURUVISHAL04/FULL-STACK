import java.util.Scanner;

public class MaskCardNumber {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your credit card number (e.g., 1234 5678 9012 3456): ");
        String cardNumber = scanner.nextLine();
        String cleaned = cardNumber.replaceAll(" ", "");
        if (cleaned.length() < 4) {
            System.out.println("Invalid card number.");
            scanner.close();
            return;
        }
        String lastFour = cleaned.substring(cleaned.length() - 4);
        StringBuilder masked = new StringBuilder();
        int maskedLength = cleaned.length() - 4;
        for (int i = 0; i < maskedLength; i++) {
            masked.append("*");
        }
        masked.append(lastFour);
        StringBuilder formatted = new StringBuilder();
        for (int i = 0; i < masked.length(); i++) {
            if (i > 0 && i % 4 == 0) {
                formatted.append(" ");
            }
            formatted.append(masked.charAt(i));
        }
        System.out.println("Masked Card Number: " + formatted.toString());

        scanner.close();
    }
}
