import java.util.Scanner;

public class WordCapitalizer {

    public static String capitalizeEachWord(String sentence) {
        if (sentence == null || sentence.isEmpty()) {
            return sentence;
        }

        String[] words = sentence.split("\\s+");
        StringBuilder capitalizedSentence = new StringBuilder();

        for (int i = 0; i < words.length; i++) {
            String word = words[i];
            if (!word.isEmpty()) {
                String firstLetter = word.substring(0, 1).toUpperCase();
                String restOfWord = word.substring(1).toLowerCase();
                
                capitalizedSentence.append(firstLetter).append(restOfWord);
            }
            
            if (i < words.length - 1) {
                capitalizedSentence.append(" ");
            }
        }

        return capitalizedSentence.toString();
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Enter a sentence:");
        String userInput = scanner.nextLine();

        System.out.println("Original: \"" + userInput + "\"");
        System.out.println("Capitalized: \"" + capitalizeEachWord(userInput) + "\"");

        scanner.close();
    }
}