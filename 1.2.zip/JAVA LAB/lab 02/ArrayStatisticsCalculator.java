import java.util.Scanner;

public class ArrayStatisticsCalculator {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter how many numbers: ");
        int n = scanner.nextInt();
        int[] numbers = new int[n];
        System.out.println("Enter " + n + " numbers:");
        for (int i = 0; i < n; i++) {
            numbers[i] = scanner.nextInt();
        }
        int max = numbers[0];
        int min = numbers[0];
        int sum = 0;
        int evenCount = 0;
        int oddCount = 0;
        for (int num : numbers) {
            if (num > max) max = num;
            if (num < min) min = num;
            sum += num;

            if (num % 2 == 0)
                evenCount++;
            else
                oddCount++;
        }
        double average = (double) sum / n;
        System.out.println("\n--- Array Statistics ---");
        System.out.println("Maximum: " + max);
        System.out.println("Minimum: " + min);
        System.out.printf("Average: %.2f\n", average);
        System.out.println("Even numbers: " + evenCount);
        System.out.println("Odd numbers: " + oddCount);

        scanner.close();
    }
}
