public class CustomStringFormatter {
    public static void main(String[] args) {
        String name = "Alice";
        float gpa = 9.2f;
        String result = String.format("Student: %-10s | GPA: %5.2f", name, gpa);
        System.out.println(result);
    }
}
