class Vehicle{
    int vehiclenumber;
    Vehicle(int vehiclenumber){
        this.vehiclenumber = vehiclenumber;
    }
}
class FourWheeler extends Vehicle{
    int noofseats;
    FourWheeler(int vehiclenumber,int noofseats){
        super(vehiclenumber);
        this.noofseats = noofseats;
    }
}
class Car extends FourWheeler{
    String cartype;
    Car(int vehiclenumber, int noofseats, String cartype){
        super(vehiclenumber,noofseats);
        this.cartype = cartype;
    }
    public void display(){
        System.out.println("Vehicle Number:" + vehiclenumber);
        System.out.println("Number of seats:" + noofseats);
        System.out.println("Car Type:" + cartype);
    }
}
public class TransportSystem{
    public static void main(String[] args){
        Car c1 = new Car(9189,7,"Bolero");
        c1.display();
    }
}
// A transport system tracks vehicle types. All vehicles have a vehicleNumber. A FourWheeler has an additional attribute numberOfSeats, and a Car has an
// attribute carType (like SUV, Sedan, etc.). Design:
//  Class Vehicle: with vehicleNumber and constructor.  Class FourWheeler: inherits Vehicle, adds numberOfSeats with a constructor.  Class Car: inherits FourWheeler, adds carType, and includes a constructor that
// initializes all fields via super constructors. Task:
// Create an object of Car and display all attributes using a method.
