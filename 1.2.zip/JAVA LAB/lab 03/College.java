class Person{
    String name;
    int id;
    Person(String name,int id){
        this.name = name;
        this.id = id;
    }
}
class Student extends Person{
    String course;
    Student(String name,int id,String course){
        super(name,id);
        this.course = course;
    }
    public void displaystudinfo(){
        System.out.println("Student name :" + name);
        System.out.println("student id:" + id);
        System.out.println("course : " + course);
    }
}
class Teacher extends Person{
    String subject;
    Teacher(String name,int id,String subject){
        super(name,id);
        this.subject = subject;
    }
     public void displayteacherinfo(){
        System.out.println("Teacher name :" + name);
        System.out.println("Student id:" + id);
        System.out.println("Subject : " + subject);
    }
}
public class College{
    public static void main(String[] args){
        Student s1 = new Student("Karthik",66,"OOPS IN JAVA");
        Teacher t1 = new Teacher("sanjeev",55,"Java");
        s1.displaystudinfo();
        t1.displayteacherinfo();

    }
}
// In a library system, every Person has a name and ID. There are two types of
// users: Student and Teacher. A Student has a course and a Teacher has a subject. Design:
//  Class Person: with name, ID, and constructor.  Class Student: inherits from Person, adds course, with a constructor.  Class Teacher: inherits from Person, adds subject, with a constructor. Task:
// Create one Student object and one Teacher object using constructors, and display their
// complete information.