interface Greet{
    void SayHello();
}
public class Ananymousinnerclass{
    public static void main(String[] args){
        Greet greeter = new Greet(){
            public void SayHello(){
                System.out.println("Good Morning!");
            }
        };
        greeter.SayHello();
    }
}
// Q3.To print a custom greeting message like &quot;Good Morning!&quot; by implementing a Greet interface, but
// only once in your program. You don’t want to create a separate class for it.
// Create an interface Greet with a method sayHello().
// Use an anonymous inner class to implement Greet and print &quot;Good Morning!&quot;.