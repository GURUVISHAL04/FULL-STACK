package employee;

public class Emp {
    String name;
    int empid;
    String category;
    double bpay, hra, da, npay, pf, grosspay, incometax, allowance;
    public Emp(String name, int empid, String category, double bpay) {
        this.name = name;
        this.empid = empid;
        this.category = category;
        this.bpay = bpay;
    }
    public void calculateHRA() {
        hra = 0.20 * bpay;
    }
    public void calculateDA() {
        da = 0.10 * bpay;
    }
    public void calculatePF() {
        pf = 0.05 * bpay;
    }
    public void calculateAllowance() {
        allowance = 0.05 * bpay;
    }
    public void calculateGrossPay() {
        grosspay = bpay + da + hra + allowance - pf;
    }
    public void calculateIncomeTax() {
        incometax = 0.40 * grosspay;
    }
    public void calculateNetPay() {
        npay = grosspay - incometax;
    }
    public void display() {
        System.out.println("\nEmployee Payroll Details:");
        System.out.println("Name: " + name);
        System.out.println("Employee ID: " + empid);
        System.out.println("Category: " + category);
        System.out.println("Basic Pay: " + bpay);
        System.out.println("HRA: " + hra);
        System.out.println("DA: " + da);
        System.out.println("Allowance: " + allowance);
        System.out.println("PF: " + pf);
        System.out.println("Gross Pay: " + grosspay);
        System.out.println("Income Tax: " + incometax);
        System.out.println("Net Pay: " + npay);
    }
}
