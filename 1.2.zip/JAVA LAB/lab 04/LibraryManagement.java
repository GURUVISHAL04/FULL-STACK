
interface Logger {
    void log();
}
class Library {
    int id;
    String name;
    public Library(int id, String name) {
        this.id = id;
        this.name = name;
    }
    class Book {
        int bookid;
        String name;
        String dateofissue;
        public Book(int bookid, String name, String dateofissue) {
            this.bookid = bookid;
            this.name = name;
            this.dateofissue = dateofissue;
            Logger logger = new Logger() {
                public void log() {
                    System.out.println("User Authenticated.");
                }
            };
            logger.log();
        }
    }
}
public class LibraryManagement {
    public static void main(String[] args) {
        Library lib = new Library(1, "City Central Library");
        Library.Book book = lib.new Book(101, "Java Programming", "2025-05-29");
    }
}
