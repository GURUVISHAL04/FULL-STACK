import employee.Emp;

public class Emppay {
    public static void main(String[] args) {
        Emp e = new Emp("Karthik", 1001, "Manager", 60000.0);
        e.calculateHRA();
        e.calculateDA();
        e.calculatePF();
        e.calculateAllowance();
        e.calculateGrossPay();
        e.calculateIncomeTax();
        e.calculateNetPay();
        e.display();
    }
}
javac- d.Emp.java