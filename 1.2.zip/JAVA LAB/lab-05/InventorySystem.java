import java.util.HashMap;
import java.util.Scanner;

class ItemNotFoundException extends Exception {
    public ItemNotFoundException(String message) {
        super(message);
    }
}

class OutOfStockException extends Exception {
    public OutOfStockException(String message) {
        super(message);
    }
}

class InventoryManager {
    private HashMap<String, Integer> inventory;

    public InventoryManager() {
        inventory = new HashMap<>();
        inventory.put("laptop", 5);
        inventory.put("phone", 3);
        inventory.put("tablet", 2);
    }

    public void sellItem(String itemName, int quantity) throws ItemNotFoundException, OutOfStockException {
        if (!inventory.containsKey(itemName.toLowerCase())) {
            throw new ItemNotFoundException("Item not found in inventory");
        }

        int available = inventory.get(itemName.toLowerCase());
        if (quantity > available) {
            throw new OutOfStockException("Insufficient stock for item: " + itemName);
        }

        inventory.put(itemName.toLowerCase(), available - quantity);
        System.out.println("Sold " + quantity + " " + itemName + "(s). Remaining: " + inventory.get(itemName.toLowerCase()));
    }
}

public class InventorySystem {
    public static void main(String[] args) {
        InventoryManager manager = new InventoryManager();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter item name: ");
        String itemName = scanner.nextLine();

        System.out.print("Enter quantity to sell: ");
        int quantity = scanner.nextInt();

        try {
            manager.sellItem(itemName, quantity);
        } catch (ItemNotFoundException e) {
            System.out.println(e.getMessage());
        } catch (OutOfStockException e) {
            System.out.println(e.getMessage());
        }

        scanner.close();
    }
}