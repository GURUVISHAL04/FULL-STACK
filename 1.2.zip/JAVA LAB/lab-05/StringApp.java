import java.util.Scanner;
import java.util.InputMismatchException;

class StringProcessor {
    public char getCharAt(String str, int index) {
        return str.charAt(index);
    }
}

public class StringApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StringProcessor processor = new StringProcessor();

        try {
            System.out.print("Enter a string: ");
            String input = sc.nextLine();

            if (input == null || input.isEmpty()) {
                throw new NullPointerException("String cannot be null or empty.");
            }

            System.out.print("Enter index to get character: ");
            int index = sc.nextInt();

            char ch = processor.getCharAt(input, index);
            System.out.println("Character at index " + index + ": " + ch);

        } catch (StringIndexOutOfBoundsException e) {
            System.out.println("Error: Index is out of bounds.");
        } catch (NullPointerException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (InputMismatchException e) {
            System.out.println("Error: Please enter a valid integer.");
        } finally {
            sc.close();
        }
    }
}