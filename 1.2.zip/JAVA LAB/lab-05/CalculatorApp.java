import java.util.InputMismatchException;
import java.util.Scanner;

class Calculator {
    public int divide(int a, int b) throws ArithmeticException {
        if (b == 0)
            throw new ArithmeticException("Cannot divide by zero.");
        return a / b;
    }
}

public class CalculatorApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Calculator calc = new Calculator();
        int[] divisors = {10, 5, 2, 0, 3};

        try {
            System.out.print("Enter index (0-4) for divisor: ");
            int index = sc.nextInt();

            System.out.print("Enter dividend: ");
            int dividend = sc.nextInt();

            int divisor = divisors[index];
            int result = calc.divide(dividend, divisor);
            System.out.println("Result: " + result);

        } catch (ArrayIndexOutOfBoundsException e) {
            System.out.println("Error: Index out of bounds. Please choose between 0 and 4.");
        } catch (InputMismatchException e) {
            System.out.println("Error: Invalid input. Please enter integers only.");
        } catch (ArithmeticException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}