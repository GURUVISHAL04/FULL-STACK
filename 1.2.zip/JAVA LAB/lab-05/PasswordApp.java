import java.util.Scanner;

class WeakPasswordException extends Exception {
    public WeakPasswordException(String message) {
        super(message);
    }
}

class EmptyPasswordException extends Exception {
    public EmptyPasswordException(String message) {
        super(message);
    }
}

class Authenticator {
    public void validatePassword(String password) throws EmptyPasswordException, WeakPasswordException {
        if (password == null || password.isEmpty()) {
            throw new EmptyPasswordException("Password cannot be empty.");
        }
        if (password.length() < 8 || !password.matches(".\\d.")) {
            throw new WeakPasswordException("Password too weak – must be at least 8 characters and include a number.");
        }
    }
}

public class PasswordApp {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        Authenticator auth = new Authenticator();

        System.out.print("Enter password: ");
        String password = sc.nextLine();

        try {
            auth.validatePassword(password);
            System.out.println("Password is valid!");
        } catch (EmptyPasswordException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (WeakPasswordException e) {
            System.out.println("Error: " + e.getMessage());
        } finally {
            sc.close();
        }
    }
}